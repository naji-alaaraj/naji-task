using ExpenseClaims.Application.DTOs;
using ExpenseClaims.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace ExpenseClaims.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ExpensesController(IExpenseService expenseService) : ControllerBase
{
    /// <summary>Employee screen: submit a new expense claim.</summary>
    [HttpPost]
    [ProducesResponseType<ExpenseDto>(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<ExpenseDto>> Create([FromBody] CreateExpenseRequest request, CancellationToken ct)
    {
        var created = await expenseService.CreateAsync(request, ct);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    /// <summary>Manager screen: filtered, paged list of expenses.</summary>
    [HttpGet]
    [ProducesResponseType<PagedResult<ExpenseDto>>(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<PagedResult<ExpenseDto>>> GetAll([FromQuery] ExpenseFilterRequest filter, CancellationToken ct)
    {
        return Ok(await expenseService.GetFilteredAsync(filter, ct));
    }

    [HttpGet("{id:int}")]
    [ProducesResponseType<ExpenseDto>(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ExpenseDto>> GetById(int id, CancellationToken ct)
    {
        var expense = await expenseService.GetByIdAsync(id, ct);
        return expense is null ? NotFound() : Ok(expense);
    }

    [HttpPut("{id:int}/approve")]
    [ProducesResponseType<ExpenseDto>(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ExpenseDto>> Approve(int id, CancellationToken ct)
    {
        var expense = await expenseService.ApproveAsync(id, ct);
        return expense is null ? NotFound() : Ok(expense);
    }

    [HttpPut("{id:int}/reject")]
    [ProducesResponseType<ExpenseDto>(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ExpenseDto>> Reject(int id, CancellationToken ct)
    {
        var expense = await expenseService.RejectAsync(id, ct);
        return expense is null ? NotFound() : Ok(expense);
    }
}
