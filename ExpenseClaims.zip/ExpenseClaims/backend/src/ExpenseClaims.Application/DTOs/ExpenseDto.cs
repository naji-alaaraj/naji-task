namespace ExpenseClaims.Application.DTOs;

public sealed record ExpenseDto(
    int Id,
    string EmployeeName,
    decimal Amount,
    DateTime RecordedAt,
    string Status);
