using System.ComponentModel.DataAnnotations;

namespace ExpenseClaims.Application.DTOs;

/// <summary>Query-string filters for the manager's expense table.</summary>
public sealed class ExpenseFilterRequest : IValidatableObject
{
    public string? EmployeeName { get; set; }

    [Range(typeof(decimal), "0", "1000000000")]
    public decimal? MinAmount { get; set; }

    [Range(typeof(decimal), "0", "1000000000")]
    public decimal? MaxAmount { get; set; }

    /// <summary>Inclusive lower bound on the recording time.</summary>
    public DateTimeOffset? FromDate { get; set; }

    /// <summary>Inclusive upper bound on the recording time.</summary>
    public DateTimeOffset? ToDate { get; set; }

    [Range(1, int.MaxValue)]
    public int Page { get; set; } = 1;

    [Range(1, 100)]
    public int PageSize { get; set; } = 10;

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (MinAmount is not null && MaxAmount is not null && MinAmount > MaxAmount)
            yield return new ValidationResult(
                "Minimum amount cannot be greater than maximum amount.",
                [nameof(MinAmount), nameof(MaxAmount)]);

        if (FromDate is not null && ToDate is not null && FromDate > ToDate)
            yield return new ValidationResult(
                "From date cannot be after to date.",
                [nameof(FromDate), nameof(ToDate)]);
    }
}
