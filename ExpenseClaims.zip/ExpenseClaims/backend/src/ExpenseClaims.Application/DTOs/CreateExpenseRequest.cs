using System.ComponentModel.DataAnnotations;

namespace ExpenseClaims.Application.DTOs;

public sealed class CreateExpenseRequest
{
    [Required(AllowEmptyStrings = false)]
    [StringLength(100, MinimumLength = 1)]
    public string EmployeeName { get; set; } = string.Empty;

    [Range(typeof(decimal), "0.01", "1000000000", ErrorMessage = "Amount must be between 0.01 and 1,000,000,000.")]
    public decimal Amount { get; set; }
}
