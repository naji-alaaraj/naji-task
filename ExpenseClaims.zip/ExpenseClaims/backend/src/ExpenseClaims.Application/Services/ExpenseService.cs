using ExpenseClaims.Application.DTOs;
using ExpenseClaims.Application.Interfaces;
using ExpenseClaims.Domain.Entities;
using ExpenseClaims.Domain.Interfaces;
using ExpenseClaims.Domain.Queries;

namespace ExpenseClaims.Application.Services;

public sealed class ExpenseService(IExpenseRepository repository, TimeProvider timeProvider) : IExpenseService
{
    public async Task<ExpenseDto> CreateAsync(CreateExpenseRequest request, CancellationToken ct = default)
    {
        var expense = new Expense(request.EmployeeName, request.Amount, timeProvider.GetUtcNow().UtcDateTime);

        await repository.AddAsync(expense, ct);
        await repository.SaveChangesAsync(ct);

        return ToDto(expense);
    }

    public async Task<ExpenseDto?> GetByIdAsync(int id, CancellationToken ct = default)
    {
        var expense = await repository.GetByIdAsync(id, ct);
        return expense is null ? null : ToDto(expense);
    }

    public async Task<PagedResult<ExpenseDto>> GetFilteredAsync(ExpenseFilterRequest filter, CancellationToken ct = default)
    {
        var query = new ExpenseQuery(
            EmployeeName: string.IsNullOrWhiteSpace(filter.EmployeeName) ? null : filter.EmployeeName.Trim(),
            MinAmount: filter.MinAmount,
            MaxAmount: filter.MaxAmount,
            FromUtc: filter.FromDate?.UtcDateTime,
            ToUtc: filter.ToDate?.UtcDateTime,
            Page: filter.Page,
            PageSize: filter.PageSize);

        var (items, total) = await repository.SearchAsync(query, ct);

        return new PagedResult<ExpenseDto>(items.Select(ToDto).ToList(), total, filter.Page, filter.PageSize);
    }

    public Task<ExpenseDto?> ApproveAsync(int id, CancellationToken ct = default) =>
        ChangeStatusAsync(id, e => e.Approve(), ct);

    public Task<ExpenseDto?> RejectAsync(int id, CancellationToken ct = default) =>
        ChangeStatusAsync(id, e => e.Reject(), ct);

    private async Task<ExpenseDto?> ChangeStatusAsync(int id, Action<Expense> change, CancellationToken ct)
    {
        var expense = await repository.GetByIdAsync(id, ct);
        if (expense is null) return null;

        change(expense);
        await repository.SaveChangesAsync(ct);

        return ToDto(expense);
    }

    private static ExpenseDto ToDto(Expense e) =>
        new(e.Id, e.EmployeeName, e.Amount, DateTime.SpecifyKind(e.RecordedAt, DateTimeKind.Utc), e.Status.ToString());
}
