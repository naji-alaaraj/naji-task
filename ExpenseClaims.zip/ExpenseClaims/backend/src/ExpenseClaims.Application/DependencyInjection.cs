using ExpenseClaims.Application.Interfaces;
using ExpenseClaims.Application.Services;
using Microsoft.Extensions.DependencyInjection;

namespace ExpenseClaims.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddSingleton(TimeProvider.System);
        services.AddScoped<IExpenseService, ExpenseService>();
        return services;
    }
}
