using ExpenseClaims.Application.DTOs;

namespace ExpenseClaims.Application.Interfaces;

/// <summary>Use cases exposed to the API layer. Controllers depend on this interface only.</summary>
public interface IExpenseService
{
    Task<ExpenseDto> CreateAsync(CreateExpenseRequest request, CancellationToken ct = default);
    Task<ExpenseDto?> GetByIdAsync(int id, CancellationToken ct = default);
    Task<PagedResult<ExpenseDto>> GetFilteredAsync(ExpenseFilterRequest filter, CancellationToken ct = default);

    /// <returns>The updated expense, or <c>null</c> if it does not exist.</returns>
    Task<ExpenseDto?> ApproveAsync(int id, CancellationToken ct = default);

    /// <returns>The updated expense, or <c>null</c> if it does not exist.</returns>
    Task<ExpenseDto?> RejectAsync(int id, CancellationToken ct = default);
}
