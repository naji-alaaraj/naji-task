using ExpenseClaims.Domain.Entities;
using ExpenseClaims.Domain.Interfaces;
using ExpenseClaims.Domain.Queries;
using ExpenseClaims.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ExpenseClaims.Infrastructure.Repositories;

public class ExpenseRepository(AppDbContext db) : IExpenseRepository
{
    public async Task AddAsync(Expense expense, CancellationToken ct = default) =>
        await db.Expenses.AddAsync(expense, ct);

    public Task<Expense?> GetByIdAsync(int id, CancellationToken ct = default) =>
        db.Expenses.FirstOrDefaultAsync(e => e.Id == id, ct);

    public async Task<(IReadOnlyList<Expense> Items, int TotalCount)> SearchAsync(ExpenseQuery query, CancellationToken ct = default)
    {
        IQueryable<Expense> q = db.Expenses.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(query.EmployeeName))
            q = q.Where(e => e.EmployeeName.Contains(query.EmployeeName));

        if (query.MinAmount is not null)
            q = q.Where(e => e.Amount >= query.MinAmount);

        if (query.MaxAmount is not null)
            q = q.Where(e => e.Amount <= query.MaxAmount);

        if (query.FromUtc is not null)
            q = q.Where(e => e.RecordedAt >= query.FromUtc);

        if (query.ToUtc is not null)
            q = q.Where(e => e.RecordedAt <= query.ToUtc);

        var total = await q.CountAsync(ct);

        var items = await q
            .OrderByDescending(e => e.RecordedAt)
            .ThenByDescending(e => e.Id)
            .Skip((query.Page - 1) * query.PageSize)
            .Take(query.PageSize)
            .ToListAsync(ct);

        return (items, total);
    }

    public Task SaveChangesAsync(CancellationToken ct = default) => db.SaveChangesAsync(ct);
}
