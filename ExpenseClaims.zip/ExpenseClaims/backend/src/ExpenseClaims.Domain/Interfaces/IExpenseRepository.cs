using ExpenseClaims.Domain.Entities;
using ExpenseClaims.Domain.Queries;

namespace ExpenseClaims.Domain.Interfaces;

public interface IExpenseRepository
{
    Task AddAsync(Expense expense, CancellationToken ct = default);
    Task<Expense?> GetByIdAsync(int id, CancellationToken ct = default);
    Task<(IReadOnlyList<Expense> Items, int TotalCount)> SearchAsync(ExpenseQuery query, CancellationToken ct = default);
    Task SaveChangesAsync(CancellationToken ct = default);
}
