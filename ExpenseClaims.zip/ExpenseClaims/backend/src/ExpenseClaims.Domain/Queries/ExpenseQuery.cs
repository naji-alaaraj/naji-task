namespace ExpenseClaims.Domain.Queries;

/// <summary>Filtering and paging criteria understood by the expense repository.</summary>
public sealed record ExpenseQuery(
    string? EmployeeName,
    decimal? MinAmount,
    decimal? MaxAmount,
    DateTime? FromUtc,
    DateTime? ToUtc,
    int Page,
    int PageSize);
