using ExpenseClaims.Domain.Enums;

namespace ExpenseClaims.Domain.Entities;

public class Expense
{
    public int Id { get; private set; }
    public string EmployeeName { get; private set; } = string.Empty;
    public decimal Amount { get; private set; }
    public DateTime RecordedAt { get; private set; }
    public ExpenseStatus Status { get; private set; }

    // Required by EF Core
    private Expense() { }

    public Expense(string employeeName, decimal amount, DateTime recordedAtUtc)
    {
        if (string.IsNullOrWhiteSpace(employeeName))
            throw new ArgumentException("Employee name is required.", nameof(employeeName));
        if (amount <= 0)
            throw new ArgumentException("Amount must be greater than zero.", nameof(amount));

        EmployeeName = employeeName.Trim();
        Amount = amount;
        RecordedAt = recordedAtUtc;
        Status = ExpenseStatus.Pending;
    }

    public void Approve() => Status = ExpenseStatus.Approved;

    public void Reject() => Status = ExpenseStatus.Rejected;
}
