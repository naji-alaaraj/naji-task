import { HttpErrorResponse } from '@angular/common/http';

/** Turns an ASP.NET Core ProblemDetails / validation response into a readable message. */
export function describeApiError(err: unknown): string {
  if (!(err instanceof HttpErrorResponse)) return 'Something went wrong.';
  if (err.status === 0) return 'Cannot reach the server. Is the API running?';

  const body = err.error as { title?: string; errors?: Record<string, string[]> } | null;
  if (body?.errors) {
    const messages = [...new Set(Object.values(body.errors).flat())];
    if (messages.length) return messages.join(' ');
  }
  return body?.title ?? `Request failed (${err.status}).`;
}
