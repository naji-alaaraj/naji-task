export type ExpenseStatus = 'Pending' | 'Approved' | 'Rejected';

export interface Expense {
  id: number;
  employeeName: string;
  amount: number;
  recordedAt: string;
  status: ExpenseStatus;
}

export interface CreateExpenseRequest {
  employeeName: string;
  amount: number;
}

export interface ExpenseFilter {
  employeeName?: string | null;
  minAmount?: number | null;
  maxAmount?: number | null;
  /** yyyy-MM-dd, interpreted in the user's local time zone */
  fromDate?: string | null;
  /** yyyy-MM-dd, inclusive, interpreted in the user's local time zone */
  toDate?: string | null;
  page: number;
  pageSize: number;
}

export interface PagedResult<T> {
  items: T[];
  totalCount: number;
  page: number;
  pageSize: number;
  totalPages: number;
}
