import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { CreateExpenseRequest, Expense, ExpenseFilter, PagedResult } from '../models/expense';

@Injectable({ providedIn: 'root' })
export class ExpenseService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = '/api/expenses';

  create(request: CreateExpenseRequest): Observable<Expense> {
    return this.http.post<Expense>(this.baseUrl, request);
  }

  search(filter: ExpenseFilter): Observable<PagedResult<Expense>> {
    let params = new HttpParams().set('page', filter.page).set('pageSize', filter.pageSize);

    const name = filter.employeeName?.trim();
    if (name) params = params.set('employeeName', name);
    if (filter.minAmount != null) params = params.set('minAmount', filter.minAmount);
    if (filter.maxAmount != null) params = params.set('maxAmount', filter.maxAmount);
    // Dates are picked in local time; send exact instants so the server filters the user's local day.
    if (filter.fromDate) params = params.set('fromDate', startOfLocalDay(filter.fromDate).toISOString());
    if (filter.toDate) params = params.set('toDate', endOfLocalDay(filter.toDate).toISOString());

    return this.http.get<PagedResult<Expense>>(this.baseUrl, { params });
  }

  approve(id: number): Observable<Expense> {
    return this.http.put<Expense>(`${this.baseUrl}/${id}/approve`, null);
  }

  reject(id: number): Observable<Expense> {
    return this.http.put<Expense>(`${this.baseUrl}/${id}/reject`, null);
  }
}

function startOfLocalDay(isoDate: string): Date {
  const [y, m, d] = isoDate.split('-').map(Number);
  return new Date(y, m - 1, d, 0, 0, 0, 0);
}

function endOfLocalDay(isoDate: string): Date {
  const [y, m, d] = isoDate.split('-').map(Number);
  return new Date(y, m - 1, d, 23, 59, 59, 999);
}
