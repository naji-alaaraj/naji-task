import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'submit' },
  {
    path: 'submit',
    title: 'Submit Expense',
    loadComponent: () => import('./features/submit-expense/submit-expense').then((m) => m.SubmitExpense),
  },
  {
    path: 'review',
    title: 'Review Expenses',
    loadComponent: () => import('./features/review-expenses/review-expenses').then((m) => m.ReviewExpenses),
  },
  { path: '**', redirectTo: 'submit' },
];
