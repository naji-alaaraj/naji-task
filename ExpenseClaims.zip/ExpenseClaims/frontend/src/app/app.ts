import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <header class="topbar">
      <span class="brand">Expense Claims</span>
      <nav>
        <a routerLink="/submit" routerLinkActive="active">Submit expense</a>
        <a routerLink="/review" routerLinkActive="active">Manager review</a>
      </nav>
    </header>
    <main class="container">
      <router-outlet />
    </main>
  `,
})
export class App {}
