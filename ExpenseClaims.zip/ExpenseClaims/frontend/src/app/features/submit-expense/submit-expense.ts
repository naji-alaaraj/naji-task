import { CurrencyPipe } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Expense } from '../../core/models/expense';
import { ExpenseService } from '../../core/services/expense.service';
import { describeApiError } from '../../core/utils/api-error';

@Component({
  selector: 'app-submit-expense',
  imports: [ReactiveFormsModule, CurrencyPipe],
  templateUrl: './submit-expense.html',
})
export class SubmitExpense {
  private readonly expenses = inject(ExpenseService);
  private readonly fb = inject(NonNullableFormBuilder);

  readonly form = this.fb.group({
    employeeName: ['', [Validators.required, Validators.maxLength(100), Validators.pattern(/\S/)]],
    amount: this.fb.control<number | null>(null, [Validators.required, Validators.min(0.01), Validators.max(1_000_000_000)]),
  });

  readonly submitting = signal(false);
  readonly error = signal<string | null>(null);
  readonly lastSaved = signal<Expense | null>(null);

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const { employeeName, amount } = this.form.getRawValue();
    this.submitting.set(true);
    this.error.set(null);

    this.expenses.create({ employeeName: employeeName.trim(), amount: amount! }).subscribe({
      next: (saved) => {
        this.lastSaved.set(saved);
        this.form.reset();
        this.submitting.set(false);
      },
      error: (err) => {
        this.error.set(describeApiError(err));
        this.submitting.set(false);
      },
    });
  }

  showError(control: 'employeeName' | 'amount'): boolean {
    const c = this.form.controls[control];
    return c.invalid && (c.touched || c.dirty);
  }
}
