import { CurrencyPipe, DatePipe } from '@angular/common';
import { Component, DestroyRef, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { Subject, debounceTime, switchMap, catchError, of, tap, merge, map } from 'rxjs';
import { Expense, ExpenseFilter, PagedResult } from '../../core/models/expense';
import { ExpenseService } from '../../core/services/expense.service';
import { describeApiError } from '../../core/utils/api-error';

const PAGE_SIZE = 10;

@Component({
  selector: 'app-review-expenses',
  imports: [ReactiveFormsModule, CurrencyPipe, DatePipe],
  templateUrl: './review-expenses.html',
})
export class ReviewExpenses {
  private readonly expenses = inject(ExpenseService);
  private readonly fb = inject(FormBuilder);
  private readonly destroyRef = inject(DestroyRef);

  readonly filters = this.fb.group({
    employeeName: this.fb.control<string | null>(''),
    minAmount: this.fb.control<number | null>(null),
    maxAmount: this.fb.control<number | null>(null),
    fromDate: this.fb.control<string | null>(null),
    toDate: this.fb.control<string | null>(null),
  });

  readonly result = signal<PagedResult<Expense> | null>(null);
  readonly page = signal(1);
  readonly loading = signal(false);
  readonly error = signal<string | null>(null);
  /** Ids of rows whose approve/reject request is in flight. */
  readonly busyIds = signal<ReadonlySet<number>>(new Set());

  private readonly reload$ = new Subject<void>();

  constructor() {
    // Filter changes reset to page 1 (debounced for typing); page changes / reloads fetch immediately.
    const filterChanged$ = this.filters.valueChanges.pipe(
      debounceTime(300),
      tap(() => this.page.set(1)),
    );

    merge(filterChanged$, this.reload$)
      .pipe(
        map(() => this.buildFilter()),
        tap(() => {
          this.loading.set(true);
          this.error.set(null);
        }),
        switchMap((filter) =>
          this.validate(filter)
            ? this.expenses.search(filter).pipe(
                catchError((err) => {
                  this.error.set(describeApiError(err));
                  return of(null);
                }),
              )
            : of(null),
        ),
        takeUntilDestroyed(this.destroyRef),
      )
      .subscribe((res) => {
        if (res) this.result.set(res);
        this.loading.set(false);
      });

    this.reload$.next();
  }

  goToPage(page: number): void {
    const total = this.result()?.totalPages ?? 1;
    if (page < 1 || page > Math.max(total, 1) || page === this.page()) return;
    this.page.set(page);
    this.reload$.next();
  }

  clearFilters(): void {
    this.filters.reset({ employeeName: '', minAmount: null, maxAmount: null, fromDate: null, toDate: null });
  }

  approve(expense: Expense): void {
    this.changeStatus(expense, this.expenses.approve(expense.id));
  }

  reject(expense: Expense): void {
    this.changeStatus(expense, this.expenses.reject(expense.id));
  }

  isBusy(id: number): boolean {
    return this.busyIds().has(id);
  }

  private changeStatus(expense: Expense, request: ReturnType<ExpenseService['approve']>): void {
    this.setBusy(expense.id, true);
    this.error.set(null);

    request.subscribe({
      next: (updated) => {
        // Reflect the new status on the row without refetching the page.
        this.result.update((r) =>
          r ? { ...r, items: r.items.map((e) => (e.id === updated.id ? updated : e)) } : r,
        );
        this.setBusy(expense.id, false);
      },
      error: (err) => {
        this.error.set(describeApiError(err));
        this.setBusy(expense.id, false);
      },
    });
  }

  private setBusy(id: number, busy: boolean): void {
    this.busyIds.update((ids) => {
      const next = new Set(ids);
      if (busy) next.add(id);
      else next.delete(id);
      return next;
    });
  }

  private buildFilter(): ExpenseFilter {
    const v = this.filters.getRawValue();
    return {
      employeeName: v.employeeName,
      minAmount: v.minAmount,
      maxAmount: v.maxAmount,
      fromDate: v.fromDate || null,
      toDate: v.toDate || null,
      page: this.page(),
      pageSize: PAGE_SIZE,
    };
  }

  private validate(f: ExpenseFilter): boolean {
    if (f.minAmount != null && f.maxAmount != null && f.minAmount > f.maxAmount) {
      this.error.set('Minimum amount cannot be greater than maximum amount.');
      return false;
    }
    if (f.fromDate && f.toDate && f.fromDate > f.toDate) {
      this.error.set('From date cannot be after to date.');
      return false;
    }
    return true;
  }
}
